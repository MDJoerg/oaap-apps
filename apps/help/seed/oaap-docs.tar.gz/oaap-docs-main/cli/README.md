---
title: "OAAP CLI-Referenz"
checked_against: "0.1.42"
checked_on: 2026-08-23
lang: de
---
# OAAP CLI-Referenz

> Geprüft gegen Referenz **0.1.42** (2026-08-23); der Abschnitt „Instanzen ansprechen“ gegen **0.1.167** (2026-10-01).

> **Vollständig und aktuell: die [erzeugte CLI-Referenz](generated/README.md).**
> Sie wird aus den Befehlsdefinitionen selbst erzeugt (`oaap help --markdown`,
> seit 0.1.248) und nennt jeden Befehl mit allen Optionen und der Angabe, ob er
> `sudo` braucht. Diese Seite hier ergänzt sie um Beispiele, Warnungen und das
> „Warum“ — wo sich beide widersprechen, gilt die erzeugte. Auf dem Knoten
> zeigt `oaap help` dieselbe Übersicht.

Das Kommando `oaap` liegt auf jedem Knoten unter `/usr/local/bin/oaap`.
Grundsätze:

- **Fast alles braucht `sudo`** — die Ausnahmen (u. a. `oaap status`,
  `oaap version`, `oaap help`, `oaap node show`, `oaap store list`, die
  lesenden Aktionen von `oaap tenant` und `oaap data`) nennt die
  [erzeugte Referenz](generated/README.md) Befehl für Befehl.
- **Das Portal kann das meiste auch.** Die CLI ist der Rettungsweg und
  der Weg für Automatisierung; im Alltag führt der Weg über
  Portal → „Instanzen" → Instanz anklicken.
- **Werte, die geheim sind** (Passwörter, Konfigurationsgeheimnisse),
  fragt die CLI versteckt ab, wenn man sie nicht als Argument angibt —
  so landen sie nicht in der Shell-Historie.

Inhalt: [Knoten](#knoten) · [Apps](#apps) · [Konfiguration &
Adressen](#konfiguration--adressen) · [Deployment](#deployment-test--produktiv) ·
[Store](#store) · [Netz: extern & Edge](#netz-externer-name--edge) ·
[Betrieb](#betrieb-backup-benutzer-flotte) · [Diagnose](#diagnose)

---

## Knoten

### `oaap status`

Gesundheit des Knotens ohne Portal: Version, Profile, Kerndienste,
Apps, **Pflegestand** (seit 0.1.220: Neustart nötig?, automatische
Updates, Gateway-Listener — jede Zeile mit ihrer Empfehlung),
Plattenplatz. Endet mit `HEALTHY` oder `DEGRADED` (Exit-Code 1).

```sh
oaap status
```

### `oaap version`

Nur die installierte Plattformversion.

### `sudo oaap setup-token`

Zeigt den Einrichtungs-Token für den ersten Browser-Setup erneut an —
nur solange noch kein Administrator existiert.

### `sudo oaap update [--check]`

Aktualisiert die Plattform aus der **hinterlegten Quelle** (kein
Auslöser kann eine andere Quelle unterschieben). Baut erst die neuen
Images und schaltet dann um — schlägt der Bau fehl, läuft alles Alte
weiter. Führt anschließend Konsistenzschritte (`migrate.sh`) aus, auch
wenn es nichts zu aktualisieren gab.

```sh
sudo oaap update --check   # zeigt nur, was sich ändern würde
sudo oaap update           # wendet an
```

Protokoll: `/var/log/oaap-update.log`. Merksatz: Fixes an der
Update-Engine selbst wirken erst beim **nächsten** Lauf.

### `oaap node show` · `sudo oaap node add-profile|remove-profile <profil>`

Wofür ist dieser Knoten da (RFC-0011)? Profil `dev` macht den Knoten
zur Werkbank: Das Portal darf dort Test-Instanzen anlegen und aus noch
nicht gelisteten Quellen installieren. Wird bewusst **nur an der
Maschine** gesetzt, nie im Portal.

```sh
oaap node show
sudo oaap node add-profile dev
sudo oaap node remove-profile dev
```

### `oaap node care` · `sudo oaap node care auto-updates on` · `sudo oaap node care reboot-window <HH:MM|off>`

Der **Pflegestand** des Knotens (seit 0.1.220, `oaap.core.updates` 2.6):
Läuft der neueste installierte Kernel, oder wartet ein Neustart? Sind
automatische Sicherheitsupdates an (Programm **und** Schalter **und**
Zeitgeber — das Paket allein setzt den Schalter nicht)? Handeln die
Gateway-Listener Multipath TCP aus (sollen sie nicht)? Dieselben drei
Zeilen stehen in `oaap status`, im Portal (Band für `server_admin`,
Seite „Gesundheit“) und im Flottenstatus — alle lesen **eine** Messung,
die der Minutenlauf alle zehn Minuten erneuert.

```sh
oaap node care                              # Anzeige (mit sudo: frisch gemessen)
sudo oaap node care auto-updates on         # Sicherheitsupdates einschalten, Schalter schreibt OAAP
sudo oaap node care reboot-window 04:15     # Knoten startet um 04:15 selbst neu, wenn ein neuer Kernel wartet
sudo oaap node care reboot-window off       # ab Werk: kein Fenster, Neustart von Hand
```

Die Einstellungen landen in `/etc/apt/apt.conf.d/52oaap-care`; die
Dateien der Distribution bleiben unberührt. Quellen ändert OAAP nie —
nur die Sicherheitsquelle der Distribution wird automatisch eingespielt
(auf einem Raspberry Pi bleibt die Kernelquelle der Stiftung bewusst
draußen). Ein Neustart-Fenster ist eine Entscheidung **je Knoten**,
sinnvoll nach dem Backup.

### `sudo oaap node care reboot at … | cancel` · `protect` · `release` — Neustart-Plan und Schutz

Seit 0.1.221 (RFC-0069, `oaap.core.updates` 2.7) startet nicht mehr die
Distribution den Knoten neu, sondern die Plattform selbst — mit **Plan**:
Wartet ein neuer Kernel und ist ein Fenster gesetzt, rechnet der
Minutenlauf einen Termin aus (das Fenster am ersten Tag **mindestens
24 Stunden** nach der Ankündigung), schreibt ihn in jedes Mandanten-Log,
zeigt ihn in `oaap status`, im Portal (Band für **jeden** Angemeldeten) und
im Flottenstatus, misst am Termin noch einmal und startet dann neu.
Danach schließt die erste Messung den Plan mit „läuft 6.12.115“.

Seit 0.1.222 (RFC-0069 Stufe 2, `oaap.core.updates` 2.7.6) ist der Plan
außerdem ein **Vorgang** in jedem Posteingang des Knotens (jede
`vorgaenge`-Instanz ab 0.3.0, Produktionskanal, eine je Mandant): angelegt
bei der Ankündigung im Bereich „Eingang“, gemeldet vom „Knoten *name*“,
fortgeschrieben bei jedem Verschieben, geschlossen nach dem Neustart mit
dem Beweis oder mit der Absage. Der Vorgang nennt keine Kernel-Version;
die steht hier in `oaap status`. Nichts zu tun — wer den Eingang liest,
weiß Bescheid. Den Schlüssel dafür prägt die Plattform selbst
(`platform:<posteingang>`, nur für root lesbar unter
`/var/lib/oaap/apps/node-case-keys.json`) und erneuert ihn 30 Tage vor
Ablauf; antwortet ein Eingang nicht, steht das im Journal des
Minutenlaufs (`journalctl -u oaap-instance-watch`), der Plan wartet nicht.

Seit 0.1.223 (RFC-0069 Stufe 3, `oaap.core.updates` 2.7.7) sagt der Knoten
den Termin auch **jeder App**: Jede Instanz bekommt `OAAP_CARE_URL`
(`http://oaap-gateway-1:8097/platform/care.json`, nur aus dem Knoten
erreichbar, kein Schlüssel nötig). Die Antwort trägt Termin, Dringlichkeit,
„gehalten“ und Zustand — keine Kernel-Version, keinen Grund. Der Desk
(`webtop` ab 0.1.10) liest sie und meldet dem Menschen den Termin, dringend
30 und 10 Minuten vorher. Eine schon laufende App erfährt die Adresse beim
nächsten Neustart ihres Containers; die Datei dahinter schreibt der
Minutenlauf, vor der ersten Messung antwortet die Tür 404 (= kein Plan).

Seit 0.1.224 (RFC-0069 Stufe 4, `oaap.core.updates` 2.7.8) ist der Plan auf
einem Knoten mit Profil `broker` außerdem ein **Ereignis**: Jede Bewegung
(angekündigt, verschoben, überstimmt, überfällig, startet, erledigt,
abgesagt) liegt als gehaltene MQTT-Nachricht auf
`oaap/<mandant>/node/<knoten>` — im Baum jedes Mandanten, der einen
Posteingang hat. Sie trägt Termin, Dringlichkeit, Grund in Worten, Schutz,
Zustand und den Satz des Vorgangs, keine Kernel-Version. Wer mit einem
Schlüssel des Mandanten `oaap/<mandant>/node/#` abonniert (zum Beispiel ein
n8n-Fluss, der eine Nachricht weiterschickt), erfährt es sofort; die letzte
Nachricht bleibt auf dem Thema, auch `done` und `cancelled`. Der Minutenlauf
sendet vom Host aus als `oaap.relay`; ist der Broker gerade weg — nach dem
Neustart kommt er spät —, wartet die Nachricht in
`/var/lib/oaap/apps/care-events-pending.json` und geht mit der nächsten
Minute. Ohne Profil `broker` passiert nichts.

Seit 0.1.225 (RFC-0069 Stufe 5, `oaap.core.updates` 2.7.2) braucht ein
Schutz die Befehlszeile nicht mehr: Die Instanzseite im Portal trägt im
Reiter „Diagnose“ die Karte **Neustart-Schutz**. Der Mandanten-Admin der
Instanz (und der Server-Admin) schützt dort mit Begründung und Ende,
verlängert und hebt auf — derselbe Weg, dieselbe Regel wie `oaap node care
protect`/`release`, geprüft vom Knoten mit Rolle und Mandant aus dem
Datensatz des Handelnden. Nach jeder Handlung rechnet der Knoten den Plan
sofort neu; Karte, Band und Protokoll zeigen die Verschiebung im selben
Augenblick.

**Dringlichkeit** kommt aus Messwerten, nicht von Hand: **kritisch**, wenn
der wartende Kernel aus der Security-Quelle stammt **und** der Knoten
exponiert ist (externer Name oder MPTCP an); sonst **Pflege**.

```sh
sudo oaap node care protect joerg-desk --reason "Schulung bis Mittwoch"   # 7 Tage, höchstens --until +30 Tage
sudo oaap node care protect joerg-desk --reason "…" --until 2026-11-12
sudo oaap node care release joerg-desk
sudo oaap node care reboot at "2026-11-08 04:15" --reason "glibc-Update"  # Plan von Hand, Uhr des Knotens
sudo oaap node care reboot at now --reason "…" [--critical]               # sofort (kürzer als 24 h = Dein ausdrücklicher Akt)
sudo oaap node care reboot cancel                                        # gespeicherten Plan zurücknehmen
```

Ein **Schutz** je Instanz hält einen **Pflege**-Neustart bis zum Tag nach
seinem Ende — mit Begründung (ohne wird abgelehnt) und Ablauf. Einen
**kritischen** Neustart hält er nicht; er wird dann als „überstimmt“
gezeigt, und der Eintrag `reboot.override` steht im Log. Ein Plan von
Hand (glibc-Fall) geht durch dieselben Regeln und ist der Weg, den
Mechanismus auf einem Testknoten zu messen, bevor ein Kernel kommt.
Die Datei `52oaap-care` sagt seitdem immer `Automatic-Reboot "false"`;
das Fenster steht dort als `OAAP::Care::Reboot-Window`.

### `sudo oaap uninstall [--purge] [--yes]`

Entfernt die Plattform vom Knoten. Ohne `--purge` bleiben die Daten
unter `/var/lib/oaap/data` liegen (Wiederaufsetzen möglich); mit
`--purge` ist **alles weg**.

---

## Apps

### `sudo oaap app install <quelle> [--path <p>] [--ref <branch>] [--name <n>] [--channel test|production]`

Installiert eine App aus einem Git-Repository oder einem lokalen
Verzeichnis. `--path` zeigt in Monorepos auf den App-Ordner, `--name`
erlaubt mehrere Instanzen derselben App, `--channel` wählt Test- oder
Produktiv-Kanal (Standard: production).

```sh
sudo oaap app install https://github.com/MDJoerg/oaap-store --path apps/uptime-kuma
sudo oaap app install https://github.com/MDJoerg/oaap-apps --path apps/studio --channel test
sudo oaap app install <git-url> --name crm-test --channel test
```

Hinweise:

- Auf dem **Produktiv-Kanal** wird die Neuinstallation derselben
  Version abgelehnt — die Version ist die einzige Antwort auf „was
  läuft da?".
- Eine erneute Installation unter gleichem Namen ist das
  **Update** der Instanz: die Daten (Storage) bleiben erhalten.
- Im Portal geht dasselbe per Ein-Klick aus dem Store.

### `sudo oaap app list`

Alle Instanzen: App, Version, Kanal, Gateway-Port, Container.

### `sudo oaap app remove <instanz> [--purge]`

Entfernt eine Instanz. Ohne `--purge` bleibt ihr Storage liegen — eine
spätere Installation gleichen Namens findet die Daten wieder.

### `sudo oaap app visibility <instanz> all|groups <g1,g2>`

Sichtbarkeits-Gruppen (RFC-0007): Die App sehen und erreichen nur noch
Benutzer, die eine der Gruppen tragen. `server_admin` sieht immer
alles. Wird echt am Gateway durchgesetzt, nicht nur im Launchpad
versteckt.

```sh
sudo oaap app visibility finanzen groups buero,finanzen
sudo oaap app visibility finanzen all
```

### `sudo oaap app tile <instanz> [auto|on|off]`

Kachel im Launchpad: `auto` folgt der App-Klasse (Frontends zeigen
eine, Hintergrunddienste nicht), `on`/`off` erzwingen es. Ohne Modus
wird der aktuelle Stand gezeigt.

### `sudo oaap app link …` / `sudo oaap app endpoint …`

Verbindungen zwischen Apps (RFC-0016) und deklarierte Nicht-HTTP-Ports
(RFC-0015). Selten nötig — die üblichen Wege laufen über das Manifest
der App. Details: `sudo oaap app link --help` bzw.
`sudo oaap app endpoint --help`.

### `sudo oaap app convert <compose-datei> [--out <ordner>]`

Werkzeug für Paket-Bauer: erzeugt aus einer docker-compose-Datei ein
OAAP-App-Gerüst (Manifest + Struktur) als Startpunkt.

---

## Konfiguration & Adressen

### `sudo oaap app config list|set|unset <instanz> [<schlüssel>] [<wert>]`

Konfigurationswerte einer Instanz — nur die im Manifest deklarierten
Schlüssel. Geheimnisse werden nie zurückgezeigt (nur „gesetzt"/„leer")
und ohne Wert-Argument versteckt abgefragt. Der Container wird neu
erzeugt (kurz nicht erreichbar); Daten, Adressen und Version bleiben.
**Kein Versions-Bump nötig — auch auf Produktiv.**

```sh
sudo oaap app config list forgejo
sudo oaap app config set registry REGISTRY_PASSWORD        # fragt versteckt
sudo oaap app config unset studio STUDIO_GIT_BASE
```

### `sudo oaap app address set|show|remove <instanz> [<hostname>]`

Eigener öffentlicher Name für eine Instanz (RFC-0009/0018), zusätzlich
zur automatischen Unteradresse `<instanz>.<knotenname>`. Wichtig, wenn
die Adresse in ausgelieferte Software wandert. Der Name muss per DNS
auf den Knoten zeigen; das Zertifikat kommt automatisch.

```sh
sudo oaap app address set bdt-hub hub.beispiel.de
sudo oaap app address show bdt-hub
```

### `sudo oaap app throttle show|set|off <instanz> [<rate>/<sekunden>]`

Mengenbremse für **öffentliche** Routen (`roles: [public]`), Standard
300 Anfragen je 60 Sekunden und Client-Adresse. Ehrlich gesagt: eine
Mengenbremse, keine Zugangskontrolle — die App muss eigene Schlüssel
zusätzlich selbst sperren.

```sh
sudo oaap app throttle set registry 1000/60
sudo oaap app throttle off intern-nur-lan
```

---

## Deployment (Test → Produktiv)

Der rote Faden: Die Projekt-KI (oder das Studio) liefert auf die
**Test**-Instanz; nach Produktiv geht es **nur durch einen Menschen** —
und zwar exakt die getesteten Bytes (RFC-0019/0020).

### `sudo oaap app token create|list|revoke [<instanz>]`

Deploy-Token für eine **Test**-Instanz — der Schlüssel, mit dem eine
Projekt-KI über den Deploy-Hook (`POST /deploy/<instanz>`) neue Stände
liefert. Wird **einmal** angezeigt, gespeichert ist nur eine Prüfsumme.
Produktiv-Instanzen bekommen nie einen.

```sh
sudo oaap app token create crm-test
sudo oaap app token revoke crm-test
```

### `sudo oaap app grant list|revoke [<instanzname>]`

Anlege-Erlaubnisse (RFC-0019): einmal verwendbare, 30 Minuten gültige
Erlaubnis, mit der die **erste** Instanz über den Paket-Weg entstehen
darf. Ausgestellt wird sie im Portal; hier sieht man offene Erlaubnisse
und widerruft sie.

### `sudo oaap app artifact list|rollback <instanz> [<paket>]`

Aufbewahrte Pakete einer Instanz (aktuell + 3 Vorgänger) ansehen und
auf einen Vorgänger **zurückrollen** — der Rückweg, den die Übernahme
bewusst nicht hat.

```sh
sudo oaap app artifact list bdt-hub
sudo oaap app artifact rollback bdt-hub
```

### Instanzen ansprechen (seit 0.1.167)

Jedes Kommando, das eine Instanz nimmt (`config`, `address`, `restart`,
`logs`, `rename`, `remove`, `visibility`, `diagnose`, `endpoint`, `tile`,
`resources`, `throttle`, `artifact`, `promote`, `rehearse`, `rehearsal`),
versteht vier Schreibweisen für dieselbe Instanz:

```sh
sudo oaap app restart sgl-hvp               # der Schlüssel (wie immer)
sudo oaap app restart sgl/hvp               # <kürzel>/<name>
sudo oaap app restart hvp --tenant sgl      # Name im Mandanten
sudo oaap app restart hvp                   # der Name aus dem Portal — nur wenn ihn genau eine Instanz trägt
```

Tragen zwei Mandanten denselben Namen, rät die Plattform nicht, sondern
nennt beide Schlüssel. Ältere Aufrufe mit dem Schlüssel gelten unverändert.
`purge` nimmt weiter den Namen einer schon entfernten Instanz; `access`,
`grant` und `token` bleiben bei ihrer bisherigen Schreibweise.

### `sudo oaap app promote <teststand> [--to <produktiv>] [--confirm] [--keep-name]` [--to <produktiv>] [--confirm]`

Übernahme nach Produktiv (RFC-0020): installiert **dasselbe Paket**
(gleiche Prüfsumme) des Teststands auf die Produktiv-Instanz — bestehend
oder neu. Nur höhere Versionen; erweitert das Paket den Rahmen der
Produktiv-Instanz (neue öffentliche Route, neuer Speicher, neuer Port),
bricht der erste Versuch ab und **nennt jeden Grund** — erst dann
bestätigt man mit `--confirm`. `--to` ist der **Name im Mandanten**; beginnt er
mit dem Kürzel des Mandanten (`--to sgl-hvp`), bricht der Aufruf ab und nennt
den Schlüssel, der entstünde — `--keep-name`, wenn das wirklich der Name sein soll.
Die Produktiv-Instanz behält Daten,
Konfiguration, Adressen und Gruppen.

```sh
sudo oaap app promote bdt-hub-test --to bdt-hub
sudo oaap app promote bdt-hub-test --to bdt-hub --confirm
```

---

## Store

### `oaap store list`

Konfigurierte Quellen mit Vertrauensklasse und Reihenfolge. Auflösung:
höchste Vertrauensklasse gewinnt; innerhalb einer Klasse entscheidet
die Reihenfolge (RFC-0012).

### `sudo oaap store add-source <url> [--name <n>] [--trust verified|unverified]`

```sh
sudo oaap store add-source \
  https://raw.githubusercontent.com/MDJoerg/oaap-apps/main/oaap-store.json \
  --name "OAAP Plattform-Apps"
```

Store-Quellen sind **je Knoten**, nicht flottenweit — bei neuen Knoten
daran denken.

### Weitere: `remove-source` · `enable` · `disable` · `trust` · `rename` · `reconcile`

`trust <quelle> verified|unverified` stuft eine Quelle ein;
`reconcile` gleicht die mitgelieferten Quellen mit dem Stand der
Plattformversion ab (läuft bei jedem `oaap update` automatisch mit).

---

## Netz: externer Name & Edge

### `sudo oaap external show|set|remove [<hostname>] [--behind-edge <edge-ip>]`

Registriert den öffentlichen Namen des Knotens: Zertifikate kommen
automatisch (Let's Encrypt), HTTP leitet auf HTTPS um, jede Instanz
bekommt ihre Unteradresse. Mit `--behind-edge` nimmt der Knoten seine
externen Namen nur noch vom Edge an (RFC-0006) und lässt das
TLS-Beenden dort.

```sh
sudo oaap external set oaap.beispiel.de
sudo oaap external set firma.beispiel.de --behind-edge 192.168.1.20
```

Der Name muss per DNS auf die öffentliche Adresse zeigen —
DynDNS-Aktualisierung gehört in den **Router**, nicht auf den Server.
Achtung Wildcard: `*.beispiel.de` deckt den **nackten Namen nicht** ab;
der Apex braucht seinen eigenen A-Record.

### `sudo oaap edge add|list|remove [<hostname>] [<ziel>] [--port <p>]`

Edge-Knoten (RFC-0006): Ein Knoten mit der einzigen Portfreigabe
routet fremde Hostnamen samt Subdomain-Baum an die zuständige
Plattform weiter. Geteilt wird nur der Eingang — Benutzer, Apps und
Backups bleiben je Plattform autonom.

```sh
sudo oaap edge add firma.beispiel.de 192.168.1.30
```

---

## Betrieb: Backup, Benutzer, Flotte

### `sudo oaap backup create [--to <ziel>]`

Plattform-Schnappschuss (Konfiguration, Registry, Instanz-Daten). Das
Ziel gehört **nie auf dieselbe Platte** — z. B. ein NAS-Mount. Das
Backup enthält alle Plattform-Geheimnisse: das Ziel muss exklusiv
berechtigt sein.

```sh
sudo oaap backup create --to /mnt/backup
```

### `sudo oaap user list` · `sudo oaap user password <benutzer> [<passwort>]`

Der Rettungsweg, wenn das Portal-Login klemmt: Konten mit Rollen und
Gruppen ansehen, Passwort neu setzen (meldet bestehende Sitzungen des
Kontos ab). Oft ist „ausgesperrt" nur ein falscher Benutzername —
erst `user list` ansehen.

### `sudo oaap fleet key issue|list|revoke [<label>]`

Flotten-Schlüssel (RFC-0021): erlaubt **ausschließlich** das Lesen der
Status-Auskunft `GET /fleet/status` dieses Knotens — für die
Flotten-Übersicht (FleetView) auf dem Verwaltungsknoten. Das Label
nennt den Beobachter; pro Beobachter ein eigener Schlüssel, dann bleibt
ein Widerruf gezielt. Der Wert wird **einmal** gezeigt; `revoke` wirkt
sofort.

```sh
sudo oaap fleet key issue fleetview@verwaltungsknoten
sudo oaap fleet key list
sudo oaap fleet key revoke fleetview@verwaltungsknoten
```

---

## Diagnose

```sh
oaap status                                          # Gesamtbild
sudo docker ps                                       # laufende Container
sudo docker logs oaap-identity-1                     # Login/Logout-Protokoll
sudo tail /var/lib/oaap/apps/deploy-log.jsonl        # letzte Deployments
sudo tail /var/log/oaap-update.log                   # letztes Update
sudo docker port oaap-gateway-1                      # fehlen 80/443? → Port-Rennen
nslookup <öffentlicher-name>                         # zeigt der Name noch hierher?
curl -s https://api.ipify.org                        # aktuelle öffentliche IP
```

**Port-Rennen beim Booten:** Belegt ein Fremd-Dienst mit
`restart=always` die Ports 80/443 vor OAAP, läuft das Gateway als „Up"
ohne veröffentlichte Ports. Fremd-Dienst entfernen, dann:
`cd /var/lib/oaap/app && sudo docker compose --project-name oaap up -d --force-recreate gateway`.
